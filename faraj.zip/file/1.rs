use rustlearn::linear_models::sgd::SGDClassifier;
use rustlearn::prelude::*;

fn main() {
    // ساخت یک مجموعه داده نمونه
    let data = vec![
        (vec![1.0, 2.0], 0),
        (vec![2.0, 3.0], 0),
        (vec![3.0, 4.0], 1),
        (vec![4.0, 5.0], 1),
    ];

    // ایجاد یک مدل طبقه‌بندی کننده
    let mut model = SGDClassifier::default();

    // آموزش مدل
    model.train(&data, 100);

    // پیش‌بینی برای یک نمونه جدید
    let prediction = model.predict(&vec![5.0, 6.0]);
    println!("Prediction: {}", prediction);
}