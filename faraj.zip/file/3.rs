use rayon::prelude::*;

fn main() {
    let data = vec![1, 2, 3, 4, 5];
    let results: Vec<i32> = data.par_iter()
        .map(|x| x * 2)
        .collect();
    println!("{:?}", results);
}