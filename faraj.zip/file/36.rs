use std::cell::RefCell;
use std::rc::Rc;

#[derive(Clone)]
struct Lazy<T> {
    inner: Rc<RefCell<Option<T>>>,
    func: Box<dyn FnOnce() -> T>,
}

impl<T> Lazy<T> {
    fn new<F>(func: F) -> Self
    where
        F: FnOnce() -> T + 'static,
    {
        Lazy {
            inner: Rc::new(RefCell::new(None)),
            func: Box::new(func),
        }
    }

    fn get(&self) -> T {
        if self.inner.borrow().is_none() {
            let value = (self.func)();
            *self.inner.borrow_mut() = Some(value);
        }
        self.inner.borrow().as_ref().unwrap().clone()
    }
}

fn main() {
    let lazy_value = Lazy::new(|| {
        println!("Calculating...");
        42
    });

    // مقدار تا زمانی که فراخوانی شود، محاسبه نمی‌شود
    println!("Value: {}", lazy_value.get());
    println!("Value again: {}", lazy_value.get()); // مقدار از حافظه کش گرفته می‌شود
}