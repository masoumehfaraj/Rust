use diesel::prelude::*;
use diesel::sqlite::SqliteConnection;

#[derive(Queryable, Insertable)]
#[table_name = "users"]
struct User {
    id: i32,
    name: String,
}

fn main() {
    let connection = SqliteConnection::establish(":memory:").unwrap();

    // ایجاد جدول
    diesel::sql_query("CREATE TABLE users (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT)").execute(&connection).unwrap();

    // درج یک رکورد
    diesel::insert_into(users::table)
        .values(&User { id: 1, name: "Alice".to_string() })
        .execute(&connection)
        .unwrap();

    // خواندن همه رکوردها
    let results = users::table.load::<User>(&connection).unwrap();
    for user in results {
        println!("{} - {}", user.id, user.name);
    }
}