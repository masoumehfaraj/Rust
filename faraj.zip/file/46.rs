use nom::{
    bytes::complete::tag,
    character::complete::{alpha1, space1},
    combinator::map,
    multi::separated_list1,
    IResult,
};

fn parse_name(input: &str) -> IResult<&str, String> {
    map(alpha1, String::from)(input)
}

fn parse_line(input: &str) -> IResult<&str, Vec<String>> {
    let (input, names) = separated_list1(space1, parse_name)(input)?;
    Ok((input, names))
}

fn main() {
    let input = "Alice Bob Charlie";
    match parse_line(input) {
        Ok((_, names)) => println!("{:?}", names),
        Err(e) => println!("Error: {:?}", e),
    }
}