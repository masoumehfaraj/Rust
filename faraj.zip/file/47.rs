use regex::Regex;

fn main() {
    let re = Regex::new(r"\b\w+\b").unwrap();
    let text = "The quick brown fox jumps over the lazy dog.";
    for cap in re.captures_iter(text) {
        println!("{}", cap.get(0).unwrap().as_str());
    }
}