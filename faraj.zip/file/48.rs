use sysinfo::{System, SystemExt};

fn main() {
    let mut system = System::new();
    system.refresh_all();

    println!("System name: {}", system.name());
    println!("OS version: {}", system.os_version());
    println!("Total memory: {} kB", system.total_memory());
}