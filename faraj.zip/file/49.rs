use gui_windows_native::{Button, Window};

fn main() {
    let window = Window::new("My First Window");
    let button = Button::new("Click me");
    window.add_child(button);
    window.show();
    window.run();
}