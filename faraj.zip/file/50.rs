use image::{DynamicImage, GenericImage, GenericImageView, ImageBuffer, Rgb};

fn main() -> Result<(), image::ImageError> {
    let img = image::open("input.png")?;

    // تبدیل تصویر به grayscale
    let gray_image = img.grayscale();

    // ذخیره تصویر جدید
    gray_image.save("output.png")?;

    Ok(())
}