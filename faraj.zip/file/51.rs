use rodio::{Decoder, Source};

fn main() {
    let device = rodio::default_output_device().unwrap();
    let source = Decoder::new_file("input.mp3").unwrap();
    let sink = rodio::Sink::new(&device);
    sink.append(source.speed(2.0));
    sink.sleep_until_end();
}