use ffmpeg::{codec::Codec, format::context::InputContext, media::Type};

fn main() -> Result<(), ffmpeg::Error> {
    let mut ctx = InputContext::open("input.mp4", Default::default())?;
    let mut stream = ctx.streams().find(|s| s.codec().unwrap().medium() == Type::Video).unwrap();
    let mut codec = stream.codec().unwrap().decoder().video().unwrap();

    let mut output_ctx = ffmpeg::format::context::OutputContext::new("output.webm", None).unwrap();
    let mut output_stream = output_ctx.add_stream(codec.parameters()).unwrap();
    let mut encoder = output_stream.encoder().video().unwrap();

    // ... (بقیه کد برای کدنکد کردن و نوشتن فریم‌ها)

    output_ctx.write_header()?;
    // ... (کدنکد کردن و نوشتن فریم‌ها)
    output_ctx.write_trailer()?;

    Ok(())
}