use reqwest;
use std::fs::File;
use std::io::Write;

fn main() -> Result<(), Box<dyn std::error::Error>> {
    let url = "https://example.com/file.zip";
    let resp = reqwest::blocking::get(url)?;
    let mut file = File::create("downloaded.zip")?;
    let content = resp.bytes()?;
    file.write_all(&content)?;
    Ok(())
}