use csv::Writer;
use std::fs::File;

fn main() -> Result<(), Box<dyn std::error::Error>> {
    let mut wtr = Writer::from_path("mydata.csv")?;
    wtr.write_record(&["column1", "column2"])?;
    wtr.write_record(&["value1", "value2"])?;

    Ok(())
}