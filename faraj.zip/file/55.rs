use xlsxwriter::{Workbook, Format};

fn main() -> Result<(), xlsxwriter::Error> {
    let mut workbook = Workbook::new("simple.xlsx")?;
    let mut worksheet = workbook.add_worksheet()?;

    let format = Format {
        bold: true,
        ..Default::default()
    };

    worksheet.write_string(0, 0, "Hello", &format)?;
    worksheet.write_number(1, 0, 123)?;

    workbook.close()?;

    Ok(())
}