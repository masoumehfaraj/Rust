use actix_web::{get, App, HttpServer};

#[derive(Serialize, Deserialize)]
struct User {
    id: i32,
    name: String,
}

#[get("/users/{id}")]
async fn get_user(id: web::Path<i32>) -> Json<User> {
    // در اینجا باید داده کاربر را از پایگاه داده یا هر منبع دیگری دریافت کنیم
    let user = User { id: id.into_inner(), name: "Alice".to_string() };
    Json(user)
}

#[actix_web::main]
async fn main() -> std::io::Result<()> {
    HttpServer::new(|| App::new().service(get_user))
        .bind("127.0.0.1:8080")?
        .run()
        .await
}